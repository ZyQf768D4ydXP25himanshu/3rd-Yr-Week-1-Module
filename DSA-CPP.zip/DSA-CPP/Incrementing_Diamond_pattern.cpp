#include <iostream>
using namespace std;

int main() {
    int n = 5;       // total rows for upper half
    int start = 3;   // starting number

    // upper half
    for(int i=0; i<n; i++) {
        int num = start + i;          // row number to print
        int count = i + 1;            // कितनी बार print करना है

        for(int j=0; j<count; j++) {
            cout << num << " ";
        }
        cout << endl;
    }

    // lower half (mirror of upper except middle row)
    for(int i=n-2; i>=0; i--) {
        int num = start + i;
        int count = i + 1;

        for(int j=0; j<count; j++) {
            cout << num << " ";
        }
        cout << endl;
    }

    return 0;
}
