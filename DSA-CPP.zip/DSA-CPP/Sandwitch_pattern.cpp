#include <iostream>
using namespace std;

int main() {
    int n = 3;       // यहाँ n=3 मतलब 3 layers (3,4,5)
    int start = 3;   // starting number

    // upper part
    for(int i=0; i<n; i++) {
        int num = start + i;          // row number to print
        int count = (2*n - 1) - (2*i); // print count: 5,3,1

        for(int j=0; j<count; j++) {
            cout << num << " ";
        }
        cout << endl;
    }

    // lower part (mirror of upper except middle row)
    for(int i=n-2; i>=0; i--) {
        int num = start + i;
        int count = (2*n - 1) - (2*i);

        for(int j=0; j<count; j++) {
            cout << num << " ";
        }
        cout << endl;
    }

    return 0;
}
