#include <iostream>
using namespace std;

int main() {
    int n = 5;  
    int start = 3; 

    for(int i=0; i<n; i++) {             
        int num = start + i;              
        int count = n - i;           
        for(int j=0; j<count; j++) {   
            cout << num << " ";
        }
        cout << endl;
    }
    return 0;
}
